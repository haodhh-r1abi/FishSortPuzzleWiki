Original exported PNGs, for reference. Not runtime screenshots. See manifest usage tags. Prefabs reference the exported Unity project and are not a standalone importable Unity package.
